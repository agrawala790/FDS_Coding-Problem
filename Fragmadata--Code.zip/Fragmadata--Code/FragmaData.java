package fragmadata;
import java.util.*;
import java.io.*;
import java.sql.*;

public class FragmaData {
    
    static LinkedHashMap<Integer,String> mov_title = null;
    static LinkedHashMap<Integer, String> mov_gen = null;
    HashMap<Integer,Double> mov_avg_rating = null;
    LinkedHashMap<Integer, ArrayList<String>> user_gen = null;
    LinkedHashMap<Integer, ArrayList<Integer>> user_mov = null;
        
    static Connection con = null;
    static PreparedStatement ps1 = null;
    static PreparedStatement ps2 = null;
    static PreparedStatement ps3 = null;
    
    public static void main(String[] args){               
        
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fragma_data","root","");
            ps1 = con.prepareStatement("insert into top_10_most_viewed_movies values(?,?,?)");
            ps2 = con.prepareStatement("insert into top_20_rated_movies values(?,?,?)");
            ps3 = con.prepareStatement("insert into genre_ranking_by_avg_rating values(?,?,?,?,?,?,?)");

        }
        catch(Exception e){
            e.printStackTrace();
            System.out.println(e);
        } 
         
        topViewedMovies();
        
        FragmaData fd = new FragmaData();
        
        fd.topViewedMovies1();
        
        fd.genreRating();
        
    }        
    
    
    public static LinkedHashMap<Integer, Integer> sortByValues(HashMap<Integer, Integer> mp) {
                
        ArrayList<Integer> keys = new ArrayList<>(mp.keySet());
        ArrayList<Integer> values = new ArrayList<>(mp.values());
        Collections.sort(values, Collections.reverseOrder());

        LinkedHashMap<Integer, Integer> sortedMap = new LinkedHashMap<>();

        for(int count : values){
            for(int m_id : keys){
                        
                if(count == mp.get(m_id)){                  
                    sortedMap.put(m_id, count);
                    keys.remove(new Integer(m_id));
                    break;
                }            
            }
        }
        return sortedMap;
    }
    
    public static LinkedHashMap<Integer, Double> sortByAvgRating(HashMap<Integer, Double> mp) {
                
        ArrayList<Integer> keys = new ArrayList<>(mp.keySet());
        ArrayList<Double> values = new ArrayList<>(mp.values());
        Collections.sort(values, Collections.reverseOrder());

        LinkedHashMap<Integer, Double> sortedMap = new LinkedHashMap<>();

        for(double rating : values){
            for(int m_id : keys){
                
                if(rating == mp.get(m_id)){
                    sortedMap.put(m_id, rating);
                    keys.remove(new Integer(m_id));
                    break;
                }
            }
        }      
        return sortedMap;
    }
    
    
    public static void topViewedMovies() {
        
        try{
            String input = "";
            Scanner sc = null;
            int movie_id = 0;
            String title = "";
            String genre = "";
            
            BufferedReader br = new BufferedReader(new FileReader("src/Ankit Agrawal/movies.csv"));
            mov_title = new LinkedHashMap<>();
            mov_gen = new LinkedHashMap<>();

////////// Mapping of movies with their title/names & genres /////////////////////////////////////////////////////                       
            while((input = br.readLine()) != null){
                sc = new Scanner(input).useDelimiter(","); 
                movie_id = Integer.parseInt(sc.next());
                //System.out.println(movie_id);
                title = sc.next();
                genre = sc.next();
                
                mov_title.put(movie_id, title); // Mapping of movies with their title/names
                mov_gen.put(movie_id, genre); // Mapping of movies with their type/genres
            }
            //System.out.println(mov_gen);
            //System.out.println(movie_id +" "+ title +" "+ genre);
            sc.close();
            br.close();
            
        }
        
        catch(IOException e){
            System.out.println(e);
        }                
    }
    
    public void topViewedMovies1(){
        
        //static LinkedHashMap<Integer, Integer> topViewedMovies2 = null;
        try{
            String input = "";
            Scanner sc = null;
            int movie_id = 0;
            int user_id = 0;
            int rating = 0;
            int timestamp = 0;
           
            BufferedReader br = new BufferedReader(new FileReader("src/Ankit Agrawal/ratings.csv"));
            HashMap<Integer, Integer> mp1 = new HashMap<>();
            HashMap<Integer, Integer> mp2 = new HashMap<>();
            user_mov = new LinkedHashMap<>();
                   
            while((input = br.readLine()) != null){
                sc = new Scanner(input).useDelimiter(","); 
                user_id = Integer.parseInt(sc.next());
                movie_id = Integer.parseInt(sc.next());
                rating = Integer.parseInt(sc.next());
                timestamp = Integer.parseInt(sc.next()); 
                //System.out.println(user_id +" "+ movie_id +" "+ rating +" "+ timestamp);
        
////////// Mapping of movies with their number of ratings/count ///////////////////////////////////////////////////////////////// 
                Integer view = mp1.get(movie_id);
                if(view != null)
                    mp1.put(movie_id, ++view);                
                else
                    mp1.put(movie_id, 1); 

////////// Mapping of movies with their total ratings //////////////////////////////////////////////////////////////////////////
                Integer rating1 = mp2.get(movie_id);
                if(rating1 != null){
                    rating = rating +  rating1;
                    mp2.put(movie_id, rating);
                }
                else
                    mp2.put(movie_id, rating); 

////////// Mapping of Users(user_id) with the list of Movies viewed/reated by them ////////////////////////////////////////////
                ArrayList<Integer> mov = user_mov.get(user_id);
                if(mov != null)
                    mov.add(movie_id);
                
                else{
                    ArrayList<Integer> mv = new ArrayList<>();
                    mv.add(movie_id);
                    user_mov.put(user_id, mv);
                }
            }
            
            br.close();            
            
            LinkedHashMap<Integer, Integer> topViewedMovies2 = sortByValues(mp1);
            System.out.println("1.1: Mapping of movieID's with their corresponding number of views in descending order");        
            System.out.println(topViewedMovies2);
            System.out.println();
            
            ArrayList<Integer> mId = new ArrayList<>(topViewedMovies2.keySet());
            ArrayList<Integer> count = new ArrayList<>(topViewedMovies2.values());
            LinkedHashMap<LinkedHashMap<Integer,String>, LinkedHashMap<Integer,Integer>> lmp = new LinkedHashMap<>();
            LinkedHashMap<Integer,String> movieIdName = new LinkedHashMap<>();
            LinkedHashMap<Integer,Integer> movieIdCount = new LinkedHashMap<>();
            
            for(int i=0; i<10; i++){
                int movieID = mId.get(i);
                String title = mov_title.get(movieID);
                int totalViews = count.get(i);
                movieIdName.put(movieID, title);
                movieIdCount.put(movieID, totalViews); 
                
                ps1.setInt(1, movieID);
                ps1.setString(2, title);
                ps1.setInt(3, totalViews);
                ps1.executeUpdate();
            }
            
////////// Mapping of 10 most viewed movies with their name and total views /////////////////////////////////////////////////////                                       
            lmp.put(movieIdName, movieIdCount);
            System.out.println("1.2: Top 10 most viewed movies with their names that are mapped with corresponding number of views in descending order");
            System.out.println(lmp.toString());
            
            System.out.println();
            System.out.println();           
            
            double total_rating = 0.0d;
            int total_count = 0;
            double avg_rating = 0.0d;
            mov_avg_rating = new HashMap<>();
            
////////// Mapping of movies with their Average Rating /////////////////////////////////////////////////////                       
            for(int m_id : mp2.keySet()){
                total_rating = mp2.get(m_id);
                total_count = mp1.get(m_id);
                avg_rating = total_rating/total_count ;
                
                mov_avg_rating.put(m_id, avg_rating);
            }
            
            //System.out.println(mp3);
            LinkedHashMap<Integer, Double> topRatedMovies2 = sortByAvgRating(mov_avg_rating);
            System.out.println("2.1: Mapping of movieID's with their Average Rating in descending order of the avg_rating");
            System.out.println(topRatedMovies2);
            System.out.println();
            
            ArrayList<Integer> key = new ArrayList<>(topRatedMovies2.keySet());
            ArrayList<Double> value = new ArrayList<>(topRatedMovies2.values());
            LinkedHashMap<Integer, Double> topRatedMovies = new LinkedHashMap<>();

////////// Mapping of movies with 20 highest ratings /////////////////////////////////////////////////////                       
            for(int i=0, j=20; i<j; i++){
                int movieID = key.get(i);
                if(mp1.get(movieID) >= 40){
                    double average_rating = topRatedMovies2.get(movieID);
                    
                    topRatedMovies.put(movieID, average_rating);
                    
                    long factor = (long) Math.pow(10,3);
                    average_rating = average_rating * factor;
                    double tmp = Math.round(average_rating);
                    double avgRating = tmp/factor;
                    
                    ps2.setInt(1, movieID);
                    ps2.setString(2, mov_title.get(movieID));
                    ps2.setDouble(3, avgRating);
                    ps2.executeUpdate();
                }
                else
                    j++;
                
            }
            System.out.println("2.2: Mapping of top 20 rated movieID's with their Average Rating (Condition: The movie should be rated/viewed by at least 40 users)");
            System.out.println(topRatedMovies);
            System.out.println();
            System.out.println();
            
        }
        
        catch(Exception e){
            e.printStackTrace();
            System.out.println(e);
        }
        
    }
     

    public static LinkedHashMap<String, Integer> sortByGenreCount(HashMap<String, Integer> mp) {
                
        ArrayList<String> keys = new ArrayList<>(mp.keySet());
        ArrayList<Integer> values = new ArrayList<>(mp.values());
        Collections.sort(values, Collections.reverseOrder());

        LinkedHashMap<String, Integer> sortedMap = new LinkedHashMap<>();

        for(int count : values){
            for(String genre : keys){
                        
                if(count == mp.get(genre)){                  
                    sortedMap.put(genre, count);
                    keys.remove(genre);
                    break;
                }            
            }
        }
        return sortedMap;
    }
    
    public void genreRating(){
        
        try{
            String input = "";
            Scanner sc = null;
            int user_id = 0;
            String gender = "";
            int age = 0;
            int occupation = 0;
            int zipCode = 0;
            
            BufferedReader br = new BufferedReader(new FileReader("src/Ankit Agrawal/users.csv"));
            LinkedHashMap<Integer, ArrayList<Integer>> mp1 = new LinkedHashMap<>();
            LinkedHashMap<Integer, ArrayList<Integer>> mp2 = new LinkedHashMap<>();
            LinkedHashMap<Integer, ArrayList<Integer>> mp3 = new LinkedHashMap<>();
            user_gen = new LinkedHashMap<>();    

            while((input = br.readLine()) != null){
                sc = new Scanner(input).useDelimiter(","); 
                user_id = Integer.parseInt(sc.next());
                gender = sc.next();
                age = Integer.parseInt(sc.next());
                occupation = Integer.parseInt(sc.next());
                zipCode = Integer.parseInt(sc.next());
                                
                if(age>17 && age<36){
                    if(mp1.get(occupation) == null){
                        ArrayList<Integer> u_1 = new ArrayList<>();
                        u_1.add(user_id);
                        mp1.put(occupation, u_1);                       
                    }
                    else
                        mp1.get(occupation).add(user_id);
                }
                
                else if(age>35 && age<51){
                    if(mp2.get(occupation) == null){
                        ArrayList<Integer> u_2 = new ArrayList<>();
                        u_2.add(user_id);
                        mp2.put(occupation, u_2);                       
                    }
                    else
                        mp2.get(occupation).add(user_id);
                }
                
                else if(age > 50){
                    if(mp3.get(occupation) == null){
                        ArrayList<Integer> u_3 = new ArrayList<>();
                        u_3.add(user_id);
                        mp3.put(occupation, u_3);                       
                    }
                    else
                        mp3.get(occupation).add(user_id);
                }
                
////////// Mapping of Users(user_id) with the list of Genres of the top rated movies(Average Rating >= 3) viewed/rated by them //////
                ArrayList<Integer> movies = user_mov.get(user_id);
                //System.out.println(movies);
                
                for(int mov_id : movies){
                    if(mov_avg_rating.get(mov_id) >= 3){
                        String s = mov_gen.get(mov_id);
                        String[] str = s.split("\\|");
                        
                        //ArrayList<String> gen = user_gen.get(user_id);
                        if(user_gen.get(user_id) != null)
                            user_gen.get(user_id).addAll(Arrays.asList(str));
                        
                        else{
                            ArrayList<String> genre = new ArrayList<>();
                            for(String st : str)
                                genre.add(st);
                            user_gen.put(user_id, genre);
                        }
                    }
                }
            }
                        
            System.out.println(3.0);
            
            for(int i=0; i<21; i++){ 
                
                ArrayList<Integer> al = mp1.get(i);
                ArrayList<Integer> bl = mp2.get(i);
                ArrayList<Integer> cl = mp3.get(i);
                
                ArrayList<String> al1 = new ArrayList<>();
                ArrayList<String> bl1 = new ArrayList<>();
                ArrayList<String> cl1 = new ArrayList<>();
                
                HashMap<String, Integer> mp = new HashMap<>();
                HashMap<String, Integer> np = new HashMap<>();
                HashMap<String, Integer> op = new HashMap<>();
                
                try{
                    for(int j=0; j<al.size(); j++){
                        ArrayList<String> al2 = user_gen.get(al.get(j));
                        al1.addAll(al2);
                    }
                }
                catch(NullPointerException e){
                    System.out.println();
                    System.out.println();
                    System.out.println("People belonging to occupation " +i+ " and age_group(18-35) have not rated any movie till now, so their genre ranking by avg_rating is not available.");
                }
              
                try{
                    for(int j=0; j<bl.size(); j++){
                        ArrayList<String> al2 = user_gen.get(bl.get(j));
                        bl1.addAll(al2);
                    }
                }
                catch(NullPointerException e){
                    System.out.println();
                    System.out.println();
                    System.out.println("People belonging to occupation " +i+ " and age_group(36-50) have not rated any movie till now, so their genre ranking by avg_rating is not available.");
                }    
                                
                try{
                    for(int j=0; j<cl.size(); j++){
                        ArrayList<String> al2 = user_gen.get(cl.get(j));
                        //System.out.println(al2);
                        cl1.addAll(al2);
                    }
                }
                catch(NullPointerException e){
                    System.out.println();
                    System.out.println();
                    System.out.println("People belonging to occupation " +i+ " and age_group(50+) have not rated any movie till now, so their genre ranking by avg_rating is not available.");
                }
                
                for(String genre : al1){                   
                    Integer count = mp.get(genre);
                    if(count == null)
                        mp.put(genre, 1);
                    else
                        mp.put(genre, ++count);                   
                }
                
                for(String genre : bl1){                   
                    Integer count = np.get(genre);
                    if(count == null)
                        np.put(genre, 1);
                    else
                        np.put(genre, ++count);                   
                }
                
                for(String genre : cl1){                   
                    Integer count = op.get(genre);
                    if(count == null)
                        op.put(genre, 1);
                    else
                        op.put(genre, ++count);                   
                }
                                
                LinkedHashMap<String, Integer> gen_rank1 = sortByGenreCount(mp);
                LinkedHashMap<String, Integer> gen_rank2 = sortByGenreCount(np);
                LinkedHashMap<String, Integer> gen_rank3 = sortByGenreCount(op);
                //System.out.println(gen_rank1);
                //System.out.println(gen_rank2);
                //System.out.println(gen_rank3);
                
                System.out.println();
                System.out.println();
                System.out.println("Ranking of genres by average rating for occup_Id = " +i+ " and age_group(18-35)");                
                
                ps3.setInt(1, i);
                ps3.setString(2, "18-35");
                
                int k=1;
                for(String str : gen_rank1.keySet()){
                    System.out.println("Rank " +k+ ": " + str);
                    k++;
                    
                    ps3.setString(k+1, str);
                    
                    if(k==6)
                        break;
                }
                ps3.executeUpdate();
                System.out.println();
                
                System.out.println("Ranking of genres by average rating for occup_Id = " +i+ " and age_group(36-50)");                
                
                ps3.setInt(1, i);
                ps3.setString(2, "36-50");
                
                k=1;
                for(String str : gen_rank2.keySet()){
                    System.out.println("Rank " +k+ ": " + str);
                    k++;
                    
                    ps3.setString(k+1, str);
                    
                    if(k==6)
                        break;
                }
                ps3.executeUpdate();
                System.out.println();
                
                System.out.println("Ranking of genres by average rating for occup_Id = " +i+ " and age_group(50+)");                
                
                ps3.setInt(1, i);
                ps3.setString(2, "50+");
                
                k=1;
                for(String str : gen_rank3.keySet()){
                    System.out.println("Rank " +k+ ": " + str);
                    k++;
                    
                    ps3.setString(k+1, str);
                    
                    if(k==6)
                        break;
                } 
                ps3.executeUpdate();
                
            }
        }
        
        catch(Exception e){
            e.printStackTrace();
            System.out.println(e);
        }
        
    }
    
}
